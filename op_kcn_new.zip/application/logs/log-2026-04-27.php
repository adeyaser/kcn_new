<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-04-27 04:20:12 --> Config Class Initialized
INFO - 2026-04-27 04:20:12 --> Hooks Class Initialized
DEBUG - 2026-04-27 04:20:12 --> UTF-8 Support Enabled
INFO - 2026-04-27 04:20:12 --> Utf8 Class Initialized
INFO - 2026-04-27 04:20:12 --> URI Class Initialized
INFO - 2026-04-27 04:20:12 --> Router Class Initialized
INFO - 2026-04-27 04:20:12 --> Output Class Initialized
INFO - 2026-04-27 04:20:12 --> Security Class Initialized
DEBUG - 2026-04-27 04:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 04:20:12 --> Input Class Initialized
INFO - 2026-04-27 04:20:12 --> Language Class Initialized
INFO - 2026-04-27 04:20:12 --> Loader Class Initialized
INFO - 2026-04-27 04:20:12 --> Helper loaded: url_helper
INFO - 2026-04-27 04:20:12 --> Helper loaded: security_helper
INFO - 2026-04-27 04:20:12 --> Helper loaded: form_helper
INFO - 2026-04-27 04:20:12 --> Database Driver Class Initialized
DEBUG - 2026-04-27 04:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-04-27 04:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 04:20:12 --> Controller Class Initialized
INFO - 2026-04-27 04:20:12 --> Model "Acl_model" initialized
INFO - 2026-04-27 04:20:12 --> Config Class Initialized
INFO - 2026-04-27 04:20:12 --> Hooks Class Initialized
DEBUG - 2026-04-27 04:20:12 --> UTF-8 Support Enabled
INFO - 2026-04-27 04:20:12 --> Utf8 Class Initialized
INFO - 2026-04-27 04:20:12 --> URI Class Initialized
INFO - 2026-04-27 04:20:12 --> Router Class Initialized
INFO - 2026-04-27 04:20:12 --> Output Class Initialized
INFO - 2026-04-27 04:20:12 --> Security Class Initialized
DEBUG - 2026-04-27 04:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 04:20:12 --> Input Class Initialized
INFO - 2026-04-27 04:20:12 --> Language Class Initialized
INFO - 2026-04-27 04:20:12 --> Loader Class Initialized
INFO - 2026-04-27 04:20:12 --> Helper loaded: url_helper
INFO - 2026-04-27 04:20:12 --> Helper loaded: security_helper
INFO - 2026-04-27 04:20:12 --> Helper loaded: form_helper
INFO - 2026-04-27 04:20:12 --> Database Driver Class Initialized
DEBUG - 2026-04-27 04:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-04-27 04:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 04:20:12 --> Controller Class Initialized
INFO - 2026-04-27 04:20:12 --> Model "Acl_model" initialized
INFO - 2026-04-27 04:20:12 --> File loaded: C:\xampphp7\htdocs\op_kcn_new\application\views\auth/login.php
INFO - 2026-04-27 04:20:12 --> Final output sent to browser
DEBUG - 2026-04-27 04:20:12 --> Total execution time: 0.0491
INFO - 2026-04-27 04:22:05 --> Config Class Initialized
INFO - 2026-04-27 04:22:05 --> Hooks Class Initialized
DEBUG - 2026-04-27 04:22:05 --> UTF-8 Support Enabled
INFO - 2026-04-27 04:22:05 --> Utf8 Class Initialized
INFO - 2026-04-27 04:22:05 --> URI Class Initialized
INFO - 2026-04-27 04:22:05 --> Router Class Initialized
INFO - 2026-04-27 04:22:05 --> Output Class Initialized
INFO - 2026-04-27 04:22:05 --> Security Class Initialized
DEBUG - 2026-04-27 04:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 04:22:05 --> Input Class Initialized
INFO - 2026-04-27 04:22:05 --> Language Class Initialized
INFO - 2026-04-27 04:22:05 --> Loader Class Initialized
INFO - 2026-04-27 04:22:05 --> Helper loaded: url_helper
INFO - 2026-04-27 04:22:05 --> Helper loaded: security_helper
INFO - 2026-04-27 04:22:05 --> Helper loaded: form_helper
INFO - 2026-04-27 04:22:05 --> Database Driver Class Initialized
DEBUG - 2026-04-27 04:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-04-27 04:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 04:22:05 --> Controller Class Initialized
INFO - 2026-04-27 04:22:05 --> Model "Acl_model" initialized
INFO - 2026-04-27 04:22:05 --> File loaded: C:\xampphp7\htdocs\op_kcn_new\application\views\auth/login.php
INFO - 2026-04-27 04:22:05 --> Final output sent to browser
DEBUG - 2026-04-27 04:22:05 --> Total execution time: 0.0833
INFO - 2026-04-27 04:22:26 --> Config Class Initialized
INFO - 2026-04-27 04:22:26 --> Hooks Class Initialized
DEBUG - 2026-04-27 04:22:26 --> UTF-8 Support Enabled
INFO - 2026-04-27 04:22:26 --> Utf8 Class Initialized
INFO - 2026-04-27 04:22:26 --> URI Class Initialized
INFO - 2026-04-27 04:22:26 --> Router Class Initialized
INFO - 2026-04-27 04:22:26 --> Output Class Initialized
INFO - 2026-04-27 04:22:26 --> Security Class Initialized
DEBUG - 2026-04-27 04:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 04:22:26 --> Input Class Initialized
INFO - 2026-04-27 04:22:26 --> Language Class Initialized
INFO - 2026-04-27 04:22:26 --> Loader Class Initialized
INFO - 2026-04-27 04:22:26 --> Helper loaded: url_helper
INFO - 2026-04-27 04:22:26 --> Helper loaded: security_helper
INFO - 2026-04-27 04:22:26 --> Helper loaded: form_helper
INFO - 2026-04-27 04:22:26 --> Database Driver Class Initialized
DEBUG - 2026-04-27 04:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-04-27 04:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 04:22:27 --> Controller Class Initialized
INFO - 2026-04-27 04:22:27 --> Config Class Initialized
INFO - 2026-04-27 04:22:27 --> Hooks Class Initialized
DEBUG - 2026-04-27 04:22:27 --> UTF-8 Support Enabled
INFO - 2026-04-27 04:22:27 --> Utf8 Class Initialized
INFO - 2026-04-27 04:22:27 --> URI Class Initialized
INFO - 2026-04-27 04:22:27 --> Router Class Initialized
INFO - 2026-04-27 04:22:27 --> Output Class Initialized
INFO - 2026-04-27 04:22:27 --> Security Class Initialized
DEBUG - 2026-04-27 04:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 04:22:27 --> Input Class Initialized
INFO - 2026-04-27 04:22:27 --> Language Class Initialized
INFO - 2026-04-27 04:22:27 --> Loader Class Initialized
INFO - 2026-04-27 04:22:27 --> Helper loaded: url_helper
INFO - 2026-04-27 04:22:27 --> Helper loaded: security_helper
INFO - 2026-04-27 04:22:27 --> Helper loaded: form_helper
INFO - 2026-04-27 04:22:27 --> Database Driver Class Initialized
DEBUG - 2026-04-27 04:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-04-27 04:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 04:22:27 --> Controller Class Initialized
INFO - 2026-04-27 04:22:27 --> Model "Acl_model" initialized
INFO - 2026-04-27 04:22:27 --> File loaded: C:\xampphp7\htdocs\op_kcn_new\application\views\auth/login.php
INFO - 2026-04-27 04:22:27 --> Final output sent to browser
DEBUG - 2026-04-27 04:22:27 --> Total execution time: 0.0488
